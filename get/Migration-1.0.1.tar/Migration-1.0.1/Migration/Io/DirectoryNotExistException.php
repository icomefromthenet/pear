<?php
namespace Migration\Io;

use Migration\Io\Exception as IoException;


class DirectoryNotExistsException extends IoException
{


}
/* End of File */
