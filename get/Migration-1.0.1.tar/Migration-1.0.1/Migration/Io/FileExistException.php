<?php
namespace Migration\Io;

use Migration\Io\Exception as IoException;

class FileExistException extends IoException
{

}
/* End of File */
