<?php
namespace Migration\Io;

use Migration\Io\Exception as IoException;


class DirectoryExistsException extends IoException
{


}
/* End of File */
