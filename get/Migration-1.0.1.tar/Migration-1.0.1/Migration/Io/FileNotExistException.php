<?php
namespace Migration\Io;

use Migration\Io\Exception as IoException;

class FileNotExistException extends IoException
{

}
/* End of File */
