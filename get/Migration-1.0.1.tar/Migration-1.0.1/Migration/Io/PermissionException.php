<?php
namespace Migration\Io;

use Migration\Io\Exception as IoException;

class PermissionException extends IoException
{

}
/* End of File */
