<?php
namespace Migration\Exceptions;

use Migration\Exception as BaseException;

class AllReadyInstalledException extends BaseException
{
    
}
/* End of File */