<?php
namespace Migration\Components\Migration;

use Migration\Exception as MigrationException;

class Exception extends MigrationException
{

}
/* End of File */
