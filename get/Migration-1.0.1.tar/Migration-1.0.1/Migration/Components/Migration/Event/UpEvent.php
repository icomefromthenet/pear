<?php

namespace Migration\Components\Migration\Event;

class UpEvent extends Base
{
   protected $name = "upEvent";
}
/* End of File */
