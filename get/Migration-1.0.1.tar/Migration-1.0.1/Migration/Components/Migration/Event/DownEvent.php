<?php

namespace Migration\Components\Migration\Event;

class DownEvent extends Base
{
    protected $name = "downEvent";

}
/* End of File */
