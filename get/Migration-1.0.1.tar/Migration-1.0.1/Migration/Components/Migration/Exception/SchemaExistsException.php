<?php
namespace Migration\Components\Migration\Exception;

use Migration\Components\Migration\Exception as MigrationException;

class SchemaExistsException extends MigrationException
{

}

/* End of File */
