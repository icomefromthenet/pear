<?php
namespace Migration\Components\Migration\Exception;

use Migration\Components\Migration\Exception as MigrationException;

class MigrationMissingException extends MigrationException
{

}

/* End of File */
