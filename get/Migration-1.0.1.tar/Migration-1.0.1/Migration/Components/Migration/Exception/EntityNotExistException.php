<?php
namespace Migration\Components\Migration\Exception;

use Migration\Components\Migration\Exception as MigrationException;

class EntityNotExistException extends MigrationException
{

}

/* End of File */
