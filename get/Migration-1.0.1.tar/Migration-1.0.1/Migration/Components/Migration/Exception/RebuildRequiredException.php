<?php
namespace Migration\Components\Migration\Exception;

use Migration\Components\Migration\Exception as MigrationException;

class RebuildRequiredException extends MigrationException
{

}

/* End of File */
