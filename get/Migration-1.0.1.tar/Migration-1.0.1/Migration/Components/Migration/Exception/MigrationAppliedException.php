<?php
namespace Migration\Components\Migration\Exception;

use Migration\Components\Migration\Exception as MigrationException;

class MigrationAppliedException extends MigrationException
{

}

/* End of File */
