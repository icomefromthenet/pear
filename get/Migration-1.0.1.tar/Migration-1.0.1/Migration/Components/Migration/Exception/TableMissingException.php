<?php
namespace Migration\Components\Migration\Exception;

use Migration\Components\Migration\Exception as MigrationException;

class TableMissingException extends MigrationException
{

}

/* End of File */
