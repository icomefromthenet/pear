<?php
namespace Migration\Components\Config;

use Migration\Components\Config\Exception as ConfigException;

class InvalidConfigException extends ConfigException
{
    
}
/* End of Class */
